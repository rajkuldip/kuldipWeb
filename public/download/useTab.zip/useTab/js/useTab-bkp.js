var useTabAddon = (function (window, undefined) {
	/*var defaults = {
		elem : $('.useTabContainer'),
		header : $('.useTabContainer').find('.useTab-header'),
		body : $('.useTabContainer').find('.useTab-body'),
		isTab : false,
		isResponsive : false
	}
	function _setDefaults() {
		if ($(defaults.header).data('type') == 'tab') {
			defaults.isTab = true;
			_loadCSS('css/useTab-tab.css');
			//_loadJS('js/useTab-tab.js');
		}

	}
	function _loadCSS(hrefLink) {
		var styleTag = document.createElement("link");
        styleTag.rel = "stylesheet";
        styleTag.type = "text/css";
        styleTag.href =  hrefLink;
        styleTag.media = "all";
        $('head').append(styleTag);
	}
	function _loadJS(hrefLink) {
		var scriptTag = document.createElement("script");
        scriptTag.type = "text/javascript";
        scriptTag.src =  hrefLink;
        scriptTag.async = true;
        $('head').append(scriptTag);
	}*/
	function init() {
		//_loadCSS('css/useTab-main.css');
		//_setDefaults();
		useTabTabs.init();
	}
	return {
		init : init
	}
})(window).init();
