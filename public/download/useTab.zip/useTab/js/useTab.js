var useTabDropdown = (function (window, undefined) {
	var defaults = {
		elem : $('.useTabContainer'),
		header : $('.useTabContainer').find('.useTab-header'),
		body : $('.useTabContainer').find('.useTab-body'),
		bodyContent : $('.useTabContainer').find('.useTab-body > div'),
		device : 'web'
	}
	var header = $(defaults.header),
		headerTabs = header.find('li');

	function _dropdownClickHandler() {
		$(document).on('click', function (event) {
			if (!$(event.target).hasClass('showTab-info') && $('.showTab-info').length > 0 ) {
				$('.showTab-info').removeClass('on');
				header.addClass('hide');
			}
		})
		$(defaults.elem).on('click', '.showTab-info', function (event) {
			var self = $(this);
			if (self.hasClass('on')) {
				self.removeClass('on');
				header.addClass('hide');
			} else {
				self.addClass('on');
				header.removeClass('hide');
			}
		});
		$(defaults.elem).on('click', 'li', function (event) {
			var self = $(this);
			$('.showTab-info').text($(this).text());
		})
	}
	function _primaryCheck() {
		defaults.device = ($(window).width() > 767) ? 'web' : 'mobile';
		if (headerTabs == undefined)
			return;
		if (defaults.device == 'web') {
				header.addClass('useTabs-web');
			var numberofTabs = headerTabs.length,
				totalWidth = header.outerWidth(true);
			header.find('li').css('width', (((totalWidth/numberofTabs)*100)/totalWidth) + '%');
		} else {
				header.addClass('useTabs-mobile-header header-dropdown hide');
				$(defaults.body).addClass('useTabs-mobile-body body-dropdown');

		}
	}
	function _setInitialize() {
		_primaryCheck();
		if (defaults.device == 'mobile') {
			$(defaults.elem).prepend('<p class="showTab-info">'+$(headerTabs[0]).text()+'</p>');
		}
		$.each(headerTabs, function (index, value) {
			$(value).attr('data-index', index);
		});
		$(header.find('li')[0]).addClass('selected');
		$(defaults.bodyContent).not($(defaults.bodyContent)[0]).addClass('hide');

		_dropdownClickHandler();
		_tabClickHandler();
	}
	function _reInitialize() {
		_primaryCheck();
		var dropdownField = $('.showTab-info');
		if (defaults.device == 'web') {
			header.removeClass('useTabs-mobile-header header-dropdown hide header-carousel');
			$(defaults.body).removeClass('body-dropdown useTabs-mobile-body');
			if (dropdownField.length > 0)
				dropdownField.remove();
		} else {
			header.removeClass('useTabs-web').find('li').css('width', 'auto');
			if (dropdownField.length <= 0) {
				$(defaults.elem).prepend('<p class="showTab-info">'+header.find('.selected').text()+'</p>');
			} else {
				dropdownField.text(header.find('.selected').text());
			}
		}
	}
	function _tabClickHandler() {
		header.on('click', 'li', function (event) {
			var self = $(this),
				selfIndex = self.data('index');
			if (self.hasClass('selected'))
				return;
			self.siblings('li').removeClass('selected').end().addClass('selected');
			var newTab = $(defaults.bodyContent)[selfIndex];
			$(newTab).removeClass('hide').siblings('div').addClass('hide');

		})
	}
	function init() {
		_setInitialize();
		$(window).on('resize', _reInitialize);
	}
	return {
		init : init
	}
})(window);

var useTabCarousel = (function (window, undefined) {
	var defaults = {
		elem : $('.useTabContainer'),
		header : $('.useTabContainer').find('.useTab-header'),
		body : $('.useTabContainer').find('.useTab-body'),
		bodyContent : $('.useTabContainer').find('.useTab-body > div'),
		device : ($(window).width() > 767) ? 'web' : 'mobile',
		deviceWidth : $('.useTabContainer').outerWidth(true)
	}
	var header = $(defaults.header),
		body = $(defaults.body),
		headerTabs = header.find('li');

	function _carouselClickHandler() {
		$(defaults.elem).on('click', '.carouselPoints > li', function (event) {
			var self = $(this);
			if (self.hasClass('selected'))
				return;
			self.siblings('li').removeClass('selected').end().addClass('selected');
			$(header.find('li')[self.data('index')]).siblings('li').removeClass('selected').end().addClass('selected');
			var totalLeft = defaults.deviceWidth * parseInt(self.data('index'));
			header.animate({
				'margin-left': '-' + totalLeft + 'px'
			}, 1000);
			body.animate({
				'margin-left': '-' + totalLeft + 'px'
			}, 1000);
		})
	}
	function _considerWeb() {
		var totalWidth = header.outerWidth(true);
		header.addClass('useTabs-web');
		headerTabs.css('width', (((totalWidth/headerTabs.length)*100)/totalWidth) + '%');
	}
	function _considerMobile() {
		defaults.deviceWidth = $('.useTabContainer').outerWidth(true);

		header.css('width', (defaults.deviceWidth * headerTabs.length) +'px')
			  .addClass('useTabs-mobile-header header-carousel');
		headerTabs.css('width', defaults.deviceWidth).css('float', 'left');

		body.css('width', (defaults.deviceWidth * headerTabs.length) +'px')
		    .addClass('useTabs-mobile-body body-carousel');
		$(defaults.bodyContent).css('width', defaults.deviceWidth).css('float', 'left').css('border', 'none');
	}
	function _setInitialize() {
		var carouselPoints='';
		$.each(headerTabs, function (index, value) {
			$(value).attr('data-index', index);
			carouselPoints += '<li data-index="'+ index +'"></li>';
		});
		$(defaults.elem).append('<ul class="carouselPoints">'+carouselPoints+'</ul>');

		if (defaults.device == 'web') {
			_considerWeb();
			$(defaults.bodyContent).not($(defaults.bodyContent)[0]).addClass('hide');
			$('.carouselPoints').addClass('hide');
		} else {
			_considerMobile();
		}

		$(header.find('li')[0]).addClass('selected');
		$(body.find('div')[0]).addClass('selected');
		$($('.carouselPoints').find('li')[0]).addClass('selected');

		_carouselClickHandler();
		_tabClickHandler();
	}
	function _reInitialize() {
		defaults.device = ($(window).width() > 767) ? 'web' : 'mobile';
		if (defaults.device == 'web') {
			_considerWeb();
			var selfIndex = header.find('.selected').data('index');

			header.removeAttr('style').removeClass('useTabs-mobile-header header-carousel');
			$(header.find('li')[selfIndex]).siblings('li').removeClass('selected').end().addClass('selected');

			body.removeAttr('style').removeClass('useTabs-mobile-body body-carousel').find('div').removeAttr('style');
			$(body.find('div')[selfIndex]).addClass('selected').removeClass('hide').siblings('div').addClass('hide');

			$('.carouselPoints').addClass('hide');

		} else {
			_considerMobile();
			var selfIndex = header.find('.selected').data('index'),
			    totalLeft = defaults.deviceWidth * parseInt(selfIndex);

			header.css('margin-left', '-' + totalLeft + 'px').removeClass('useTabs-web').find('li').removeClass('hide');
			$(header.find('li')[selfIndex]).addClass('selected');

			body.css('margin-left', '-' + totalLeft + 'px').find('div').removeClass('hide');
			$(body.find('div')[selfIndex]).addClass('selected');

			$('.carouselPoints').removeClass('hide');
			$($('.carouselPoints').find('li')[selfIndex]).siblings('li').removeClass('selected').end().addClass('selected');

		}
	}
	function _tabClickHandler() {
		header.on('click', 'li', function (event) {
			var self = $(this),
				selfIndex = self.data('index');
			if (self.hasClass('selected'))
				return;
			self.siblings('li').removeClass('selected').end().addClass('selected');
			$(body.find('div')[selfIndex]).addClass('selected');
			var newTab = $(defaults.bodyContent)[selfIndex];
			$(newTab).removeClass('hide').siblings('div').addClass('hide');

		})
	}
	function init() {
		if (headerTabs == undefined)
			return;
		_setInitialize();
		$(window).on('resize', _reInitialize);
	}
	return {
		init : init
	}
})(window);

var useTabAccordian = (function (window, undefined) {
	var defaults = {
		elem : $('.useTabContainer'),
		header : $('.useTabContainer').find('.useTab-header'),
		body : $('.useTabContainer').find('.useTab-body'),
		bodyContent : $('.useTabContainer').find('.useTab-body > div'),
		device : ($(window).width() > 767) ? 'web' : 'mobile',
		deviceWidth : $('.useTabContainer').outerWidth(true)
	}
	var header = $(defaults.header),
		body = $(defaults.body),
		headerTabs = header.find('li');

	function _considerWeb() {
		var totalWidth = header.outerWidth(true);
		header.addClass('useTabs-web').removeClass('useTabs-mobile-header header-slider');
		headerTabs.css({
			'width': (((totalWidth/headerTabs.length)*100)/totalWidth) + '%',
			'height': 'auto'
		}).find('> div').remove();
		body.removeClass('hide');
	}
	function _considerMobile() {
		defaults.deviceWidth = $('.useTabContainer').outerWidth(true);
		header.addClass('useTabs-mobile-header header-slider').removeClass('useTabs-web');
		headerTabs.css('width', '100%');
		body.addClass('hide');
		headerTabs.css('height', '').find(' > div').remove();
	}
	function _setInitialize() {
		$.each(headerTabs, function (index, value) {
			$(value).attr('data-index', index);
		});

		if (defaults.device == 'web') {
			_considerWeb();
			$(defaults.bodyContent).not($(defaults.bodyContent)[0]).addClass('hide');
		} else {
			_considerMobile();
			$(header.find('li')[0]).siblings('li').css('height', '38px').end().append('<div>'+ $(body.find('div')[0]).text() + '</div>');
		}

		$(header.find('li')[0]).addClass('selected');
		$(body.find('div')[0]).addClass('selected');

		_tabClickHandler();
	}
	function _reInitialize() {
		defaults.device = ($(window).width() > 767) ? 'web' : 'mobile';
		if (defaults.device == 'web') {
			_considerWeb();
		} else {
			_considerMobile();

			var newTab = body.find('> .selected');
			header.find('.selected').append('<div>'+ $(newTab).html() + '</div>');
			var totalHeight = parseInt(header.find(' > .selected > div').outerHeight(true)) + 38;
			header.find('> .selected').css('height', totalHeight+'px');
		}
	}
	function _tabClickHandler() {
		header.on('click', 'li', function (event) {
			var self = $(this),
				selfIndex = self.data('index');
			if (self.hasClass('selected'))
				return;
			var newTab = $(defaults.bodyContent)[selfIndex];
			$(newTab).removeClass('hide').siblings('div').addClass('hide');
			$(defaults.bodyContent).removeClass('selected');
			$(body.find('div')[selfIndex]).addClass('selected');
			self.siblings('li').removeClass('selected').end().addClass('selected');
			self.siblings('li').find(' > div').remove();
			if (self.parent().hasClass('header-slider')) {
				self.siblings('li').find(' > div').remove().end().end().append('<div>'+ $(newTab).html() + '</div>');
				var totalHeight = parseInt(self.find(' > div').outerHeight(true)) + 38;
				self.animate({
					height: totalHeight+'px'
				}, 150).siblings('li').animate({
					height: '38px'
				}, 150);

			}
		})
	}
	function init() {
		if (headerTabs == undefined)
			return;
		_setInitialize();
		$(window).on('resize', _reInitialize);
	}
	return {
		init : init
	}
})(window);

var useTabAddon = (function (window, undefined) {
	function _loadCSS(hrefLink) {
		var styleTag = document.createElement("link");
        styleTag.rel = "stylesheet";
        styleTag.type = "text/css";
        styleTag.href =  hrefLink;
        styleTag.media = "all";
        $('head').append(styleTag);
	}
	function init() {
		if ($('.useTabContainer').length > 0) {
			var responsiveType = $('.useTabContainer').find('.useTab-header').data('responsive');
			if (responsiveType == 'carousel') {
				useTabCarousel.init();
			} else if (responsiveType == 'accordian') {
				useTabAccordian.init();
			} else {
				useTabDropdown.init();
			}
			_loadCSS('css/useTab.css');
		}
	}
	return {
		init : init
	}
})(window).init();
