var useTabTabs = (function (window, undefined) {
	var defaults = {
		elem : $('.useTabContainer'),
		header : $('.useTabContainer').find('.useTab-header'),
		body : $('.useTabContainer').find('.useTab-body'),
		bodyContent : $('.useTabContainer').find('.useTab-body > div')
	}
	var header = $(defaults.header);

	function _setInitialize() {
		var headerTabs = header.find('li');
		if (headerTabs == undefined)
			return;
		$.each(headerTabs, function (index, value) {
			$(value).attr('data-index', index);
		})
		var numberofTabs = headerTabs.length,
			totalWidth = header.outerWidth(true);
		header.find('li').css('width', (((totalWidth/numberofTabs)*100)/totalWidth) + '%');
		$(header.find('li')[0]).addClass('selected');

		$(defaults.bodyContent).not($(defaults.bodyContent)[0]).addClass('hide');


		_tabClickHandler();
	}
	function _tabClickHandler() {
		header.on('click', 'li', function (event) {
			var self = $(this),
				selfIndex = self.data('index');
			if (self.hasClass('selected'))
				return;
			self.siblings('li').removeClass('selected').end().addClass('selected');
			var newTab = $(defaults.bodyContent)[selfIndex];
			$(newTab).removeClass('hide').siblings('div').addClass('hide');

		})
	}
	function init() {
		_setInitialize();
	}
	return {
		init : init
	}
})(window).init()